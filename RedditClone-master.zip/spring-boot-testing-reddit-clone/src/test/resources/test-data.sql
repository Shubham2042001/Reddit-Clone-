INSERT INTO user
(`user_id`,
`created`,
`email`,
`enabled`,
`password`,
`username`)
VALUES
(null ,
null ,
'test@email.com',
true,
's3cr3t',
'testuser_sql');
